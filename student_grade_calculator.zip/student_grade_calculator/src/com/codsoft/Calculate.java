package com.codsoft;
import java.util.Scanner;

public class Calculate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;
        int[] marks = null;
        boolean marksEntered = false;
        int  n_of_sub = 0;

        do {
            System.out.println("\n***** STUDENT GRADE CALCULATOR MENU *****");
            System.out.println("1. Enter Marks");
            System.out.println("2. Calculate Total, Percentage and Grade");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    try {
                        System.out.print("Enter the number of subjects: ");
                        n_of_sub= sc.nextInt();

                        if ( n_of_sub <= 0) {
                            throw new Exception("Number of subjects must be greater than 0.");
                        }

                        marks = new int[ n_of_sub];

                        for (int i = 0; i <  n_of_sub; i++) {
                            System.out.printf("Enter marks for Subject %d : ", i + 1);
                            int mark = sc.nextInt();
                            if (mark < 0 || mark > 100) {
                                throw new Exception("Marks must be between 0 and 100.");
                            }
                            marks[i] = mark;
                        }

                        marksEntered = true;
                        System.out.println("Marks entered successfully!");

                    } catch (Exception e) {
                        marks = null;
                        marksEntered = false;
                        System.out.println("Error: " + e.getMessage());
                        sc.nextLine(); 
                    }
                    break;

                case 2:
                    try {
                        if (!marksEntered) {
                            System.out.println("Please enter marks first using option 1.");
                            break;
                        }

                        int totalMarks = 0;
                        for (int mark : marks) {
                            totalMarks += mark;
                        }

                        double averagePercentage = totalMarks / (double)  n_of_sub;

                        String grade;
                        if (averagePercentage >= 90) {
                            grade = "O Grade";
                        } else if (averagePercentage >= 80) {
                            grade = "A+ Grade";
                        } else if (averagePercentage >= 70) {
                            grade = "A Grade";
                        } else if (averagePercentage >= 60) {
                            grade = "B+ Grade";
                        } else if (averagePercentage >= 50) {
                            grade = "B Grade";
                        } else if (averagePercentage >= 40) {
                            grade = "P Grade";
                        } else {
                            grade = "F Grade";
                        }

                        System.out.println("\n*******RESULT*******");
                        System.out.println("Total Marks        : " + totalMarks + " / " + ( n_of_sub * 100));
                        System.out.printf("Percentage         : %.2f%%\n", averagePercentage);
                        System.out.println("Grade              : " + grade);

                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.println("exit...Thank you!");
                    break;

                default:
                    System.out.println("Invalid choice! Please enter valid choice 1, 2, or 3.");
            }

        } while (choice != 3);

        sc.close();
    }
}
